import React from 'react';

interface BrandLogoProps {
  variant?: 'light' | 'dark';
  showSlogan?: boolean;
  className?: string;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  variant = 'dark',
  showSlogan = false,
  className = '',
}) => {
  const isLight = variant === 'light';
  const textColor = isLight ? 'text-white' : 'text-slate-900';
  const subtextColor = isLight ? 'text-slate-300' : 'text-slate-600';

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      {/* SVG Kedge Geometric Mark */}
      <div className="relative w-9 h-9 shrink-0 flex items-center justify-center rounded-lg bg-[#0a192f] p-1.5 shadow-sm border border-slate-700/30">
        <svg
          viewBox="0 0 36 36"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full"
          aria-hidden="true"
        >
          {/* Stylized Kedge Anchor & Shield Geometry */}
          <path
            d="M18 4V28M18 28C11 28 8 20 8 16M18 28C25 28 28 20 28 16"
            stroke="#ffffff"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M12 9H24"
            stroke="#ffffff"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          <circle cx="18" cy="7" r="2.5" stroke="#ffffff" strokeWidth="2" />
          {/* KEDGE Red Accent Keystone */}
          <path
            d="M16 17L18 19.5L20 17"
            stroke="#c51f1f"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>

      <div className="flex flex-col">
        <span className={`text-lg font-bold tracking-tight uppercase font-display leading-none ${textColor}`}>
          KEDGE <span className="text-[#c51f1f]">INSURANCE</span>
        </span>
        <span className={`text-[10px] tracking-wider uppercase font-medium mt-0.5 ${subtextColor}`}>
          Brokers Ltd
        </span>
        {showSlogan && (
          <span className="text-[11px] italic text-slate-400 mt-1">
            “With You From Now, Into The Future”
          </span>
        )}
      </div>
    </div>
  );
};
