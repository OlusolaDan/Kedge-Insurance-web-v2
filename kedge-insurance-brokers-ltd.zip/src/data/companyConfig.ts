export interface CompanyConfiguration {
  legalName: string;
  tradingName: string;
  brandSlogan: string;
  brandPersonality: string[];
  
  // Official Contact Channels (Real corporate communication desk)
  headOffice: {
    addressLine1: string;
    city: string;
    state: string;
    country: string;
    verificationStatus: 'Pending Final Management Confirmation' | 'Verified';
  };
  phoneNumbers: {
    primary: string;
    directDesk: string;
    display: string;
  };
  emails: {
    generalEnquiry: string;
    quoteDesk: string;
    claimsSupport: string;
    renewals: string;
  };
  officeHours: string;

  // Regulatory & Statutory Declarations
  regulatory: {
    regulatoryBody: string;
    naicomLicenceNumber: string;
    ncribMembershipNumber: string;
    cacRegistrationNumber: string;
    statusNote: string;
  };

  // Corporate Philosophy (Proposed & documented for management sign-off)
  philosophy: {
    vision: string;
    mission: string;
    coreValues: {
      name: string;
      definition: string;
    }[];
    statusNote: string;
  };
}

export const COMPANY_CONFIG: CompanyConfiguration = {
  legalName: 'KEDGE Insurance Brokers Ltd',
  tradingName: 'KEDGE Insurance Brokers',
  brandSlogan: 'With You From Now, Into The Future',
  brandPersonality: [
    'Professional',
    'Trustworthy',
    'Modern',
    'Client-focused',
    'Knowledgeable',
    'Dependable',
    'Forward-looking',
    'Technologically progressive',
  ],

  headOffice: {
    addressLine1: 'Commercial Avenue, Victoria Island',
    city: 'Lagos',
    state: 'Lagos State',
    country: 'Nigeria',
    verificationStatus: 'Pending Final Management Confirmation',
  },

  phoneNumbers: {
    primary: '+234 1 700 4334',
    directDesk: '+234 803 000 5334',
    display: '+234 (0) 1 700 4334 / +234 803 000 KEDGE',
  },

  emails: {
    generalEnquiry: 'enquiries@kedgeinsurance.com.ng',
    quoteDesk: 'quotes@kedgeinsurance.com.ng',
    claimsSupport: 'claims@kedgeinsurance.com.ng',
    renewals: 'renewals@kedgeinsurance.com.ng',
  },

  officeHours: 'Monday – Friday: 8:00 AM – 5:00 PM (WAT)',

  regulatory: {
    regulatoryBody: 'National Insurance Commission (NAICOM)',
    naicomLicenceNumber: 'RBC-LIC-[Awaiting Final Regulatory License Filing]',
    ncribMembershipNumber: 'NCRIB/MBR/[Pending Secretarial Confirmation]',
    cacRegistrationNumber: 'RC-[Pending Corporate Affairs Commission Number]',
    statusNote: 'Statutory registration and NAICOM operating licence details are designated configuration fields pending final board verification.',
  },

  philosophy: {
    vision:
      'To be a trusted insurance brokerage and risk advisory partner, recognised for professional excellence, innovative solutions and lasting value to the people and businesses we serve.',
    mission:
      'To help individuals, businesses and organisations identify, understand and manage their risks by providing professional insurance advice, suitable insurance solutions, dependable client service and support throughout the insurance lifecycle.',
    coreValues: [
      {
        name: 'Integrity',
        definition: 'Acting honestly, ethically, and transparently in every advisory engagement and client representation.',
      },
      {
        name: 'Professionalism',
        definition: 'Applying rigorous insurance technical knowledge, diligence, and the highest standards of the broking profession.',
      },
      {
        name: 'Client Focus',
        definition: 'Genuinely understanding each client’s unique operating exposures and structuring tailored protection.',
      },
      {
        name: 'Accountability',
        definition: 'Taking end-to-end ownership for advisory guidance, policy execution, and claims settlement advocacy.',
      },
      {
        name: 'Excellence',
        definition: 'Pursuing uncompromising quality, technical precision, and continuous operational improvement.',
      },
      {
        name: 'Innovation',
        definition: 'Leveraging contemporary risk management tools and seamless digital channels to enhance the client experience.',
      },
      {
        name: 'Trust',
        definition: 'Fostering enduring relationships built on strict confidentiality, consistency, and dependability.',
      },
    ],
    statusNote: 'Corporate philosophy statements are proposed and awaiting final executive board ratifications.',
  },
};
