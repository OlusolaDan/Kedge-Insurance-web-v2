# KEDGE Insurance Brokers Ltd — Corporate Web Application & Risk Advisory Portal

Official corporate website for **KEDGE Insurance Brokers Ltd**, a Nigerian insurance brokerage and risk advisory firm operating under the regulatory oversight of the **National Insurance Commission (NAICOM)**.

Brand Slogan: *“With You From Now, Into The Future”*

---

## 1. Architecture & Technology Stack

- **Frontend:** React 19 SPA with TypeScript (`.tsx`)
- **Styling & Design System:** Tailwind CSS v4 with custom brand tokens (Deep Navy `#0a192f`, KEDGE Red `#c51f1f`, clean typography hierarchy with *Plus Jakarta Sans* & *Outfit*)
- **Icons:** `lucide-react`
- **Backend & Middleware:** Node.js Express server (`server.ts`) with Vite dev middleware
- **Form Workflows:** Real server-side input validation, sanitization, spam protection, and unique tracking code generation (`KDG-QUO-2026-XXXX`, `KDG-ENQ-2026-XXXX`, `KDG-RNW-2026-XXXX`)
- **Database / Store:** Structured in-memory storage with `/api/submissions` review endpoint and JSON export capability
- **Regulatory Framework:** Aligned with the **Nigerian Insurance Act 2003**, **Pension Reform Act 2014**, **NOGICD Act 2010**, **Nigeria Data Protection Act (NDPA) 2023**, and NAICOM operational guidelines.

---

## 2. Information Architecture & Implemented Routes

| Route | Page | Purpose & Features |
|---|---|---|
| `/` | **Home** | Premium hero, statutory proof strip, service overview, sector cards, philosophy summary, insights preview, CTA, office summary |
| `/about` | **About Us** | Company identity, broker vs. agent distinction, 4-stage advisory method, Corporate Philosophy (Vision, Mission, 7 Core Values) |
| `/services` | **Insurance Services** | Complete 18+ product directory, search bar, category tabs, compulsory filter toggle, modal detail drawer |
| `/industries` | **Industries Served** | 11 distinct Nigerian sectors (SMEs, Manufacturing, Construction, Logistics, Importers, Marine, Energy, Agriculture, etc.) |
| `/risk-management` | **Risk Management** | 8-step advisory framework, loss prevention, renewal planning, broker scope boundaries |
| `/insights` | **Insurance Insights** | Educational articles on compulsory covers, Form M marine cargo, NIID verification, claims best practices |
| `/contact` | **Contact Us** | Verified office details, telephone desks, email addresses, working hours, and real `/api/contact` form |
| `/quote` | **Request a Quote** | Dynamic category quote builder, sum insured estimates, and real `/api/quote` submission with reference tracking |
| `/claims-assistance` | **Claims Assistance** | Step-by-step claims guide, time-barred notification warnings, document checklist by class, adjuster coordination |
| `/renewal-enquiry` | **Renewal Enquiry** | Independent policy benchmarking, policy audit intake connected to `/api/renewal` |
| `/faq` | **FAQ** | Comprehensive answers on NAICOM, compulsory covers, condition of average, deductibles, and broker benefits |
| `/privacy-policy` | **Privacy Policy** | Comprehensive compliance notice under the Nigeria Data Protection Act (NDPA) 2023 |
| `/terms` | **Terms of Use** | Website conditions, broker capacity disclaimers, and Uberrima Fides (Utmost Good Faith) legal disclosures |
| `/coverage-matrix` | **Coverage Matrix** | Internal audit matrix mapping all services to official NAICOM classes and statutory legal citations |
| `/404` | **Not Found** | Branded error recovery page with direct pathways to active corporate departments |

---

## 3. Local Installation & Development

### Prerequisites
- Node.js (version 20 or higher)
- npm (version 10 or higher)

### Setup & Launch
```bash
# 1. Install dependencies
npm install

# 2. Run the full-stack development server (Express backend + Vite frontend on port 3000)
npm run dev

# 3. Compile and check TypeScript types
npm run lint

# 4. Production build
npm run build

# 5. Start production server
npm start
```

---

## 4. API Endpoints

- `GET /api/health`: Server health check and timestamp.
- `POST /api/quote`: Validates name, email, phone, category, description, and privacy consent. Returns reference `KDG-QUO-2026-XXXX`.
- `POST /api/contact`: Validates general inquiry inputs and privacy consent. Returns reference `KDG-ENQ-2026-XXXX`.
- `POST /api/renewal`: Validates policyholder, insurance class, contact details, and notes. Returns reference `KDG-RNW-2026-XXXX`.
- `GET /api/submissions`: Internal audit inspection endpoint returning all submitted forms.

---

## 5. How to Add or Edit an Insurance Service

All published services are managed in `src/data/servicesData.ts`. To add a new insurance class or update terms:

1. Open `src/data/servicesData.ts`.
2. Add an entry matching the `InsuranceService` interface:
```typescript
{
  id: 'cyber-risk-liability',
  name: 'Corporate Cyber Risk & Data Protection Liability',
  category: 'Liability',
  shortDescription: 'Shields against financial loss, forensic investigation, and regulatory fines under NDPA 2023.',
  fullDescription: '...',
  isCompulsoryInNigeria: false,
  statutoryBasis: 'Nigerian Cybercrimes Act 2015 & NDPA 2023 compliance standards.',
  naicomClass: 'General Insurance Business - Liability',
  targetAudience: ['FinTechs', 'Commercial Banks', 'Corporate Entities'],
  keyRisksCovered: ['Ransomware extortion', 'Data breach notifications', 'Forensic accounting fees'],
  coverageConsiderations: ['Prior acts retroactive dates', 'Multi-factor authentication warranties'],
  standardExclusions: ['Unpatched known vulnerabilities', 'Hostile state cyber warfare'],
}
```
3. Update `src/data/coverageMatrixData.ts` to log its NAICOM classification and legal citation.

---

## 6. Regulatory Verification & Outstanding Disclosures

Per corporate governance protocols, specific configuration fields are designated in `src/data/companyConfig.ts` awaiting final executive board sign-off:
- Official Registered Office Street Address: *[Pending Final Board Confirmation]*
- NAICOM Operating Brokerage Licence Number: *[Pending Formal Regulatory Filing]*
- NCRIB Membership Registration Number: *[Pending Secretarial Confirmation]*
- CAC Registration Number: *[Pending Confirmation]*

These fields are explicitly flagged in the configuration and rendered with transparency across the website.
